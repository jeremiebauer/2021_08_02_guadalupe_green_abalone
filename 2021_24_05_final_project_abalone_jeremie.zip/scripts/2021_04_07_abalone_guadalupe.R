# If you don't yet have tidyverse run:
# install.packages("tidyverse")
library(tidyverse)

# We will require this package to handle some dates in this dataset
# install.packages("lubridate")
library(lubridate)

library(readr)
gpe <- read_csv("C:/Users/Jeremie Bauer/Desktop/Doctorado/clases/EDA_R_2021/final_project/data_raw/2021_04_07_abalone_isla_guadalupe.csv")
Parsed with column specification:
  cols(
    Sitio = col_character(),
    Transecto = col_double(),
    Profundidad = col_character(),
    numero_organismo = col_double(),
    spp = col_character(),
    `Coordenada X (Transecto)` = col_character(),
    `Coordenada Y (- izq) (+ der)` = col_character(),
    size_cm = col_character()
  )



head(gpe)

sapply(gpe, class) 
gpe$size_cm <- as.numeric(gpe$size_cm)
gpe$`Coordenada X (Transecto)` <- as.numeric(gpe$`Coordenada X (Transecto)`)
gpe$`Coordenada Y (- izq) (+ der)` <- as.numeric(gpe$`Coordenada Y (- izq) (+ der)`)

range(gpe$Profundidad)


-------------------------------------------
  #Data Visual

plot(gpe$size_cm)

# Recall in base plot this will return a boxplot
plot(size_cm ~ Sitio, data=gpe)

# In ggplot 'geom_boxplot()' would achieve this
ggplot(data=gpe, aes(x = Sitio, y = size_cm)) +
  geom_boxplot()

# Adding datapoints may reveal some pattern not easy to see in a whiskerplot
ggplot(data=gpe, aes(x = Sitio, y = size_cm)) +
  geom_jitter() + # This prevents data points from overlapping
  geom_boxplot(alpha=0.7)

#Vamos a explorar si hay un patron en longitud de concha por profundidad

a <- ggplot(data=gpe, aes(x = Profundidad, y = size_cm))

a + geom_boxplot()

plot(size_cm ~ Profundidad, data=gpe)

# In ggplot 'geom_boxplot()' would achieve this
ggplot(data=gpe, aes(x = Profundidad, y = size_cm)) +
  geom_boxplot()

# Adding datapoints may reveal some pattern not easy to see in a whiskerplot
ggplot(data=gpe, aes(x = Profundidad, y = size_cm)) +
  geom_jitter() + # This prevents data points from overlapping
  geom_boxplot(alpha=0.7)


ggsave(filename = "figure%03d.png", plot = last_plot(),  device = png(),  
path = "C:Users/Jeremie Bauer/Desktop", scale = 1,
width = 20,  height = 16,  units = cm,  dpi = 300,  limitsize = TRUE)

-----------------------------------------------------------------------------
  #STATISTICS SIMPLE LINEAR REGRESSION
  # Load custom R functions
  source("./functions/6003Functions.R")

fit <- lm(size_cm ~ Sitio, data=gpe)

# Extract predicted and residuals values
gpe$predicted <- predict(fit)
gpe$residuals <- residuals(fit)

# Basic scatterplot
b <- ggplot(gpe, aes(x = Sitio, y = size_cm)) +
  geom_point() + theme_bw() 
b

# Add a lm

b + geom_smooth(method="lm", se=FALSE, color="darkgrey")

# Without lm, but with predicted values 

b + geom_point(aes(y=predicted), shape=1, color="blue")

# With predicted values + residuals

b + geom_point(aes(y=predicted), shape=1, color="blue") +
  geom_segment(aes(xend=Sitio, yend=predicted), alpha=0.5, color="red")

# With line and residuals

b + geom_segment(aes(xend=Sitio, yend=predicted), alpha=0.5, color="red") +
  geom_smooth(method="lm", se=FALSE, color="blue")

# With residuals visualized as actual squares

x1 <- gpe$Sitio
x2 <- gpe$Sitio+gpe$residuals
y1 <- gpe$predicted
y2 <- gpe$predicted+gpe$residuals

b + geom_smooth(method="lm", se=FALSE, color="blue") +
  geom_rect(aes(xmin=x1, ymin=y1, xmax=x2, ymax=y2), alpha=0.5)

