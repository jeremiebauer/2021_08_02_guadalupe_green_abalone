gpegreen <- read_csv("C:/Users/Jeremie Bauer/Desktop/Doctorado/TESIS/Cap4_wild_population/monitoreo_guadalupe/data_raw/15_07_2021_greenabalone_fishery.csv")


head(gpegreen) #revisemos de que esta formado la tibble del csv gpe.

sapply(gpegreen, class) #La clase de cada uno


range(gpegreen$Size) 
range(gpegreen$Weigth)
range(gpegreen$Sex) 
str(gpegreen$Site) 

gpegreen$Polygon <- as.character(gpegreen$Polygon)


str(gpegreen)

#Ahora veamos un box plot con ggplot del size por cada site por sex
bp <- ggplot(data=gpegreen, aes(x = Site, y = Size, fill=Sex)) +
  geom_boxplot()+ theme(axis.text.x = element_text(angle=90, hjust=1))

bp + scale_fill_brewer(palette="Dark2")


#Ahora veamos un boxplot por SEX del tama�o por cada sitio 
ggplot(data=gpegreen, aes(x = Site, y = Size, fill=Sex)) +
  geom_boxplot()+ facet_wrap(~Sex) + theme(axis.text.x = element_text(angle=90, hjust=1))

# Vamos a a�adir DATAPOINTS para facilitar encontrar patrones en la visualizacion de los datos
ggplot(data=gpegreen, aes(x = Site, y = Size, fill=Sex)) +
  geom_jitter(color="black") + # This prevents data points from overlapping
  geom_boxplot(alpha=0.7) +  theme(axis.text.x = element_text(angle=90, hjust=1))

#Ahora veamos un box plot con ggplot del tama�o por cada sitio
ggplot(data=gpegreen, aes(x = Site, y = Weigth, by=Sex)) +
  geom_boxplot()+ theme(axis.text.x = element_text(angle=90, hjust=1))

# Vamos a a�adir DATAPOINTS para facilitar encontrar patrones en la visualizacion de los datos
ggplot(data=gpegreen, aes(x = Site, y = Weigth)) +
  geom_jitter() + # This prevents data points from overlapping
  geom_boxplot(alpha=0.7) +  theme(axis.text.x = element_text(angle=90, hjust=1))

#Ahora veamos un box plot con ggplot del tama�o por sex , por cada poligono
bp2 <- ggplot(data=gpegreen, aes(x = Polygon, y = Size, fill=Sex)) +
  geom_boxplot()+ theme(axis.text.x = element_text(angle=90, hjust=1))



#Ahora veamos un boxplot por CADA POLYGON
bppoly <- ggplot(data=gpegreen, aes(x = Polygon, y = Size, fill=Sex)) +
  geom_boxplot()+facet_wrap(~Polygon, scales ="free") + theme(axis.text.x = element_text(angle=90, hjust=1))

bppoly + scale_fill_brewer(palette="Dark2")
# Vamos a a�adir DATAPOINTS para facilitar encontrar patrones en la visualizacion de los datos

bp4 <- ggplot(data=gpegreen, aes(x = Polygon, y = Size, fill=Sex)) +
  geom_jitter() + # This prevents data points from overlapping
  geom_boxplot(alpha=0.7) +  theme(axis.text.x = element_text(angle=90, hjust=1))

bp4

bp4 + scale_fill_brewer(palette="Dark2")
