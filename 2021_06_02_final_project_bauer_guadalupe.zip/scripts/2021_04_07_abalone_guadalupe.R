
# install.packages("tidyverse")
library(tidyverse)


# install.packages("lubridate")
library(lubridate)


# install.packages("readr")
library(readr)

# install.packages("ggpubr")
library(ggpubr)

# install.packages("broom")
library(broom)

# install.packages("AICcmodavg")
library(AICcmodavg)

# install.packages("devtools")
library(devtools)


source("./functions/6003Functions.R")




gpe <- read_csv("C:/Users/Jeremie Bauer/Desktop/Doctorado/clases/EDA_R_2021/final_project/data_raw/2021_04_07_abalone_isla_guadalupe.csv")
dataoneway <- read_csv("C:/Users/Jeremie Bauer/Desktop/Doctorado/clases/EDA_R_2021/final_project/data_raw/oneway.csv")
#Parsed with column specification:
  cols(
    Sitio = col_character(),
    Transecto = col_character(),
    Profundidad = col_character(),
    numero_organismo = col_character(),
    spp = col_character(),
    `Coordenada X (Transecto)` = col_character(),
    `Coordenada Y (- izq) (+ der)` = col_character(),
    size_cm = col_character()
  )



head(gpe)

sapply(gpe, class) 
gpe$size_cm <- as.numeric(gpe$size_cm)
gpe$Sitio <- as.character(gpe$Sitio)
gpe$Profundidad <- as.character(gpe$Profundidad)
gpe$`Coordenada X (Transecto)` <- as.numeric(gpe$`Coordenada X (Transecto)`)
gpe$`Coordenada Y (- izq) (+ der)` <- as.numeric(gpe$`Coordenada Y (- izq) (+ der)`)

dataoneway$Sitio <- as.factor(dataoneway$Sitio)
dataoneway$Profundidad <- as.factor(dataoneway$Profundidad)
dataoneway$size_cm <- as.numeric(dataoneway$size_cm)

range(gpe$Profundidad)
range(gpe$Sitio)
range(gpe$size_cm)

str(dataoneway)

str(gpe)




-------------------------------------------
  #Data Visual

plot(gpe$size_cm)

# Recall in base plot this will return a boxplot
plot(size_cm ~ Sitio, data=gpe)

# In ggplot 'geom_boxplot()' would achieve this
ggplot(data=gpe, aes(x = Sitio, y = size_cm)) +
  geom_boxplot()

# Adding datapoints may reveal some pattern not easy to see in a whiskerplot
ggplot(data=gpe, aes(x = Sitio, y = size_cm)) +
  geom_jitter() + # This prevents data points from overlapping
  geom_boxplot(alpha=0.7) +  theme(axis.text.x = element_text(angle=90, hjust=1))

#Vamos a explorar si hay un patron en longitud de concha por profundidad

a <- ggplot(data=gpe, aes(x = Profundidad, y = size_cm))

a + geom_boxplot()

plot(size_cm ~ Profundidad, data=gpe)

# In ggplot 'geom_boxplot()' would achieve this
ggplot(data=gpe, aes(x = Profundidad, y = size_cm)) +
  geom_boxplot()

# Adding datapoints may reveal some pattern not easy to see in a whiskerplot
ggplot(data=gpe, aes(x = Profundidad, y = size_cm)) +
  geom_jitter() + # This prevents data points from overlapping
  geom_boxplot(alpha=0.7)


---------------------------------------------------------------------------
  #8 pasos de exploraci??n de datos
  
  #1. Outliers, Y and X
  
  par(mfrow=c(1,2)) # Just to put four plots together
boxplot(dataoneway$size_cm, main="Size_cm")


# Dotchart
dotchart(dataoneway$size_cm, main="Size_cm")
 


range(dataoneway$size_cm)


dotchart(dataoneway$size_cm, groups=factor(dataoneway$Sitio)) #By site
dotchart(dataoneway$size_cm, groups=factor(dataoneway$Profundidad)) # By depth
par(mfrow=c(1,1)) # Back to single plot per plot window

#2 Homogeinity of variance

p <- ggplot(data=dataoneway, aes(x=Sitio, y=size_cm)) +
  geom_boxplot() + facet_wrap(~Profundidad) + theme(axis.text.x = element_text(angle=90, hjust=1))
p

#3 Normality Y

par(mfrow=c(1,1))
hist(dataoneway$size_cm) #normal

# Another way to look at it:
qqnorm(dataoneway$size_cm)
qqline(dataoneway$size_cm)



range(dataoneway$size_cm) 


p <- ggplot(data=dataoneway, aes(x=size_cm)) +
  geom_histogram() + facet_wrap(~Sitio)
p

p <- ggplot(data=dataoneway, aes(x=size_cm)) +
  geom_histogram() + facet_wrap(~Profundidad)
p 


#4 Zero inflation Y

plot(table(dataoneway$size_cm)) # No zeroes at all
sum(dataoneway$size_cm == 0) #No, really, there are no zeroes


#5 Collinearity Y ------- NO CORRE EL CODIGO ERROR : ARGUMENTO FINITO XLIM

#str(gpe)

#gpe$Sitio <- as.factor(gpe$Sitio)
#gpe$Profundidad <- as.factor(gpe$Profundidad)
#gpe$spp <- as.factor(gpe$spp)

str(gpe)


pairs(~ Profundidad + Sitio + size_cm , 
      lower.panel=panel.smooth, upper.panel=panel.cor, 
      #additional code to make function work
      data=dataoneway) 

#6 RELACI??N Y CON X

# Plot all covariates against Y

p <- ggplot(data=dataoneway, aes(x=Sitio, y=size_cm)) + geom_boxplot() + theme(axis.text.x = element_text(angle=90, hjust=1))
q <- ggplot(data=dataoneway, aes(x=Profundidad, y=size_cm)) + geom_point()


multiplot(p,q, cols = 2)


s <- ggplot(data=dataoneway, aes(x=Sitio, y=size_cm)) + geom_jitter() + theme(axis.text.x = element_text(angle=90, hjust=1))
r <- ggplot(data=dataoneway, aes(x=Profundidad, y=size_cm)) + geom_jitter()

multiplot(p,q,r,s, cols = 4) 




#STATISTICS 

#ONE-WAY ANOVA size Vs Sites 

model1 <- lm(size_cm ~ Sitio, data = dataoneway)

anova(model1)

summary(model1)


#Simple Linear regression size Vs Depth 


SLR <- lm(size_cm ~ Profundidad, data=dataoneway)

summary(SLR)

# Extract predicted and residuals values
gpe$predicted <- predict(SLR)
gpe$residuals <- residuals(SLR)

# Basic scatterplot
b <- ggplot(gpe, aes(x = Profundidad, y = size_cm)) +
  geom_point() + theme_bw() + theme(axis.text.x = element_text(angle=90, hjust=1))
b

# Add a lm

b + geom_smooth(method="lm", se=FALSE, color="darkgrey")

# Without lm, but with predicted values 

b + geom_point(aes(y=predicted), shape=1, color="blue")

# With predicted values + residuals

b + geom_point(aes(y=predicted), shape=1, color="blue") +
  geom_segment(aes(xend=Sitio, yend=predicted), alpha=0.5, color="red")


